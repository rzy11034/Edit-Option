# 更新日志

## v1.0
1. Git 版本为 v2.26.2 。
2. 提取当前最新稳定版 [源码](https://github.com/git-for-windows/git) 中的 git-gui.pot 和 zh_cn.po 文件。
3. 添加 ChangeLog.md 文件。
4. 更新 README.md 和 zh_cn.msg 文件。
5. 优化和详细描述制作过程。
## v0.0
1. Git 版本为 v2.22.0 。
2. 使用当前最新稳定版源码中的文件  git-gui.pot 和 zh_cn.po 。
3. 只包含 README.md 和 zh_cn.msg 文件。